import tkinter as tk
import numpy as np
from tkinter.filedialog import askopenfile



tkk = tk.Tk()
outval = "check"
root_number = 1

tree_arr=[]
a = []
nnode = 0

canvas = tk.Canvas(tkk, width=600, height=300)
canvas.grid(columnspan=3, rowspan=3)



#instructions
instructions = tk.Label(tkk, text="NUMBER OF INDEPENDENT SETS IN A TREE", font="Helvetica 18 bold" )
instructions.grid(columnspan=3, column=0, row=1)

    


#instructions
instructions = tk.Label(tkk, text="Select a tree input text file from your computer", font="Raleway")
instructions.grid(columnspan=3, column=0, row=2)
result_text = tk.StringVar()
result_text.set("")

input_text = tk.StringVar()
input_text.set("")

#################################################################################


def open_file():  

    input_text.set("")  
    result_text.set("") 
   
    file = askopenfile(mode ='r', filetypes =[('Text Files', '*.txt')])
    if file is not None: 
        print(file.name)
        file1 = open(file.name, "r")

       

        with open(file.name) as f:
            for line in f:
                a.append([int(v) for v in line.split()])

        print(a)      
                  

        data= file1.read()
        outval="check2"  
        input_text.set(data)
        tree_creation()
   
    file1.seek(0)   
    
    file1.close() 

#######################################################################




# with open('p6.txt') as f:
#     for line in f:
#         a.append([int(v) for v in line.split()])

# print(a)

# nnode = a[0][0]


 

def f(n,b):
    nnode = a[0][0]
    vv = 1    
    if len(b) == 1:
        return ( 1 )
    else:

        for i in range(1,len(b)):          
            for j in range(1,nnode+1):
                if b[i] == a[j][0]:
                    # print(b[i],' - ',j)
                    vv = vv * g(n,a[j])
        return ( vv)  
            
def g(n,b):
    nnode = a[0][0]
    vv = 1    
    # print(b)
    if len(b) == 1:
        return ( 1 )
    else:

        for i in range(1,len(b)):  
            for j in range(1,nnode+1):
                if b[i] == a[j][0]:
                    # print(b[i],' - ',j)
                    vv = vv * (f(n,a[j]) + g(n,a[j]) )
        return (vv )  





def tree_creation(): 
    
    result_text.set("") 
    
    n=1
    output = f(n,a[n])+g(n,a[n])
    print('output ',output) 
    result_text.set(output)
    a.clear()




#browse button
browse_text = tk.StringVar()
browse_btn = tk.Button(tkk, textvariable=browse_text, command=lambda:open_file(), font="Raleway", bg="#20bebe", fg="white", height=2, width=15)
browse_text.set("Browse")
browse_btn.grid(columnspan=3, column=0, row=3)

output_label = tk.Label(tkk, text="INPUT DATA", font="Helvetica 18 bold")
output_label.grid(columnspan=3, column=0, row=5)
  
output_label = tk.Label(tkk, textvariable=input_text, font="Raleway")
output_label.grid(columnspan=3, column=0, row=7)

output_label = tk.Label(tkk, text="RESULT", font="Helvetica 18 bold")
output_label.grid(columnspan=3, column=0, row=12)

output_label = tk.Label(tkk, textvariable=result_text, font="Raleway")
output_label.grid(columnspan=3, column=0, row=15)


tkk.mainloop()
